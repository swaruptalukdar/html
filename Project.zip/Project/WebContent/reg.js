function fun1() {

	var uname = document.getElementById("uid").value;
	var amount = document.getElementsById("aid").value;
	/*var value = document.forms[0].elements[0].value;

	alert("ur value is " + value);
*/
	if (amount < 500) {
		alert(uname+"paid " +amount);

	} else {
		alert("invalid amount");
	}

	if (uname == "Javeed") {
		alert("welcome " +uname);

	} else {
		alert("sorry");
	}

	alert("welcome" +uname);
	document.write("hi friends...");
}